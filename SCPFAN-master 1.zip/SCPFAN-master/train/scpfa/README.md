
## Dependencies & Installation
Please refer to the following simple steps for installation. Datas can be download from Baidu cloud disk [[url]](https://pan.baidu.com/s/15WjlGRhYOtVNRYTj3lfE6A) (pwd: al4m)

```
conda env create -f environment.yml
conda activate scpfa
```

## Training
```
python train.py --config ./configs/scpfa_light_x4.yml
```
